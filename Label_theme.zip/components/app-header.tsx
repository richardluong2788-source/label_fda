'use client'

import { useState } from 'react'
import {
  Home, Database, BarChart3, TrendingUp, Tag,
  History, ScanLine, Settings, Menu, BookOpen,
} from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { UserProfileMenu } from '@/components/user-profile-menu'
import { LanguageSwitcher } from '@/components/language-switcher'
import { useTranslation } from '@/lib/i18n'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'

interface AppHeaderProps {
  email?: string
  isAdmin?: boolean
  showAuth?: boolean
}

export function AppHeader({ email, isAdmin, showAuth = true }: AppHeaderProps) {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)
  const { t } = useTranslation()

  const navItems = [
    { href: '/dashboard', label: t.nav.home,           icon: Home,       exact: true },
    { href: '/analyze',   label: t.nav.analyze,        icon: ScanLine,   exact: false },
    { href: '/history',   label: t.nav.history,        icon: History,    exact: false },
    { href: '/guide',     label: t.nav.guide,          icon: BookOpen,   exact: false },
    { href: '/settings',  label: t.nav.settings,       icon: Settings,   exact: false },
    ...(isAdmin
      ? [
          { href: '/admin/knowledge', label: t.nav.knowledgeBase, icon: Database,   exact: false },
          { href: '/admin/revenue',   label: t.nav.revenue,       icon: TrendingUp, exact: false },
          { href: '/admin/pricing',   label: t.nav.pricing,       icon: Tag,        exact: false },
          { href: '/admin',           label: t.nav.adminPanel,    icon: BarChart3,  exact: true },
        ]
      : []),
  ]

  const isActive = (href: string, exact: boolean) =>
    exact ? pathname === href : pathname === href || pathname.startsWith(href + '/')

  return (
    <header className="border-b bg-background/95 backdrop-blur-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          {/* Mobile hamburger */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0">
              <SheetHeader className="p-4 border-b">
                <SheetTitle className="flex items-center gap-3">
                  <Image src="/images/logo.png" alt="AI Label Pro by Vexim Global" width={36} height={36} className="rounded-lg" />
                  <div>
                    <div className="text-sm font-bold leading-tight">AI Label Pro</div>
                    <div className="text-xs text-muted-foreground leading-tight">by Vexim Global</div>
                  </div>
                </SheetTitle>
              </SheetHeader>

              <nav className="flex flex-col p-2" role="navigation" aria-label="Mobile navigation">
                {navItems.map((item) => {
                  const Icon = item.icon
                  const active = isActive(item.href, item.exact)
                  return (
                    <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)}>
                      <Button
                        variant={active ? 'secondary' : 'ghost'}
                        className="w-full justify-start gap-3 h-11"
                      >
                        <Icon className="h-4 w-4 shrink-0" />
                        {item.label}
                      </Button>
                    </Link>
                  )
                })}
              </nav>

              {/* Mobile user info */}
              {showAuth && email && (
                <div className="mt-auto border-t p-4">
                  <p className="text-sm font-medium truncate">{email}</p>
                  <p className="text-xs text-muted-foreground">
                    {isAdmin ? t.common.admin : t.common.user}
                  </p>
                  <div className="flex flex-col gap-1 mt-3">
                    <Link href="/profile" onClick={() => setMobileOpen(false)}>
                      <Button variant="ghost" size="sm" className="w-full justify-start">
                        {t.nav.profile}
                      </Button>
                    </Link>
                    <form action="/auth/logout" method="post" className="w-full">
                      <Button
                        variant="ghost"
                        size="sm"
                        type="submit"
                        className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        {t.nav.logout}
                      </Button>
                    </form>
                  </div>
                </div>
              )}
            </SheetContent>
          </Sheet>

          {/* Logo */}
          <Link href="/dashboard" className="flex items-center gap-3 shrink-0">
            <Image src="/images/logo.png" alt="AI Label Pro by Vexim Global" width={40} height={40} className="rounded-lg" />
            <div className="hidden sm:block">
              <h1 className="text-base font-bold leading-tight">AI Label Pro</h1>
              <p className="text-xs text-muted-foreground leading-tight">by Vexim Global</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1" role="navigation" aria-label="Main navigation">
            {navItems.map((item) => {
              const Icon = item.icon
              const active = isActive(item.href, item.exact)
              return (
                <Link key={item.href} href={item.href}>
                  <Button
                    variant={active ? 'secondary' : 'ghost'}
                    size="sm"
                    className="gap-2"
                  >
                    <Icon className="h-4 w-4" />
                    <span className="hidden lg:inline">{item.label}</span>
                  </Button>
                </Link>
              )
            })}
          </nav>
        </div>

        <div className="flex items-center gap-1">
          <LanguageSwitcher />
          {showAuth && email && <UserProfileMenu email={email} isAdmin={isAdmin} />}
        </div>
      </div>
    </header>
  )
}
