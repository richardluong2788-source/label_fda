'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import {
  Upload,
  FileText,
  Search,
  Filter,
  Trash2,
  Edit,
  Save,
  X,
  BookOpen,
  Database,
  Tag,
  AlertTriangle,
} from 'lucide-react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import { AppHeader } from '@/components/app-header'
import { toast } from '@/hooks/use-toast'

interface KnowledgeEntry {
  id: string
  content: string
  metadata: {
    industry?: string
    doc_type?: string
    section?: string
    severity?: string
    source?: string
    title?: string
  }
  created_at: string
}

interface Props {
  userId: string
  userRole: string
  userEmail?: string
}

const INDUSTRIES = [
  'Beverage',
  'Supplement',
  'Meat',
  'Dairy',
  'Seafood',
  'Bakery',
  'Cosmetics',
  'General',
]

const DOC_TYPES = [
  'CFR_Law',
  'FDA_Guidance',
  'Internal_Checklist',
  'Case_Study',
  'Best_Practice',
]

const SEVERITIES = ['Critical', 'Warning', 'Info']

export function KnowledgeManagement({ userId, userRole, userEmail }: Props) {
  const [entries, setEntries] = useState<KnowledgeEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [uploading, setUploading] = useState(false)
  const [showUploadForm, setShowUploadForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [filterIndustry, setFilterIndustry] = useState<string>('all')
  const [filterDocType, setFilterDocType] = useState<string>('all')
  const [currentPage, setCurrentPage] = useState(1)
  const [groupBy, setGroupBy] = useState<'none' | 'section' | 'source'>('section')
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set())

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    industry: '',
    docType: '',
    section: '',
    severity: '',
    source: '',
  })

  const supabase = createClient()

  useEffect(() => {
    loadEntries()
  }, [])

  const loadEntries = async () => {
    setLoading(true)
    const { data, error } = await supabase
      .from('compliance_knowledge')
      .select('*')
      .order('created_at', { ascending: false })

    if (data) {
      setEntries(data)
    }
    setLoading(false)
  }

  const handleUpload = async () => {
    if (!formData.content || !formData.title) {
      toast({ title: 'Thieu thong tin', description: 'Vui long nhap tieu de va noi dung', variant: 'destructive' })
      return
    }

    setUploading(true)

    try {
      const response = await fetch('/api/knowledge/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: formData.content,
          metadata: {
            title: formData.title,
            industry: formData.industry || 'General',
            doc_type: formData.docType || 'Internal_Checklist',
            section: formData.section,
            severity: formData.severity || 'Info',
            source: formData.source || 'Internal',
          },
        }),
      })

      if (response.ok) {
        toast({ title: 'Thanh cong', description: 'Tai len thanh cong!' })
        setShowUploadForm(false)
        setFormData({
          title: '',
          content: '',
          industry: '',
          docType: '',
          section: '',
          severity: '',
          source: '',
        })
        loadEntries()
      } else {
        toast({ title: 'Loi', description: 'Loi khi tai len', variant: 'destructive' })
      }
    } catch (error) {
      console.error('Upload error:', error)
      toast({ title: 'Loi', description: 'Loi khi tai len', variant: 'destructive' })
    }

    setUploading(false)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Bạn có chắc muốn xóa mục này?')) return

    const { error } = await supabase.from('compliance_knowledge').delete().eq('id', id)

    if (!error) {
      loadEntries()
    }
  }

  const filteredEntries = entries.filter((entry) => {
    const matchesSearch =
      searchQuery === '' ||
      entry.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.metadata.title?.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesIndustry =
      filterIndustry === 'all' || entry.metadata.industry === filterIndustry

    const matchesDocType =
      filterDocType === 'all' || entry.metadata.doc_type === filterDocType

    return matchesSearch && matchesIndustry && matchesDocType
  })

  // Group entries by section or source
  const groupedEntries = () => {
    if (groupBy === 'none') {
      return { 'all': filteredEntries }
    }
    
    const groups: Record<string, KnowledgeEntry[]> = {}
    
    for (const entry of filteredEntries) {
      const key = groupBy === 'section' 
        ? (entry.metadata.section || 'Không có section')
        : (entry.metadata.source || 'Không có nguồn')
      
      if (!groups[key]) {
        groups[key] = []
      }
      groups[key].push(entry)
    }
    
    return groups
  }

  const groups = groupedEntries()
  const groupKeys = Object.keys(groups).sort()
  
  // Pagination for groups
  const ITEMS_PER_PAGE = 20
  const totalPages = Math.ceil(groupKeys.length / ITEMS_PER_PAGE)
  const paginatedGroupKeys = groupKeys.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  )

  const toggleGroup = (groupKey: string) => {
    const newExpanded = new Set(expandedGroups)
    if (newExpanded.has(groupKey)) {
      newExpanded.delete(groupKey)
    } else {
      newExpanded.add(groupKey)
    }
    setExpandedGroups(newExpanded)
  }

  const isAdmin = ['admin', 'superadmin', 'expert'].includes(userRole)

  return (
    <div className="min-h-screen bg-background">
      <AppHeader email={userEmail} isAdmin={isAdmin} />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-semibold mb-1">Quản lý Tri thức (Knowledge Base)</h1>
              <p className="text-sm text-muted-foreground">
                Nạp và quản lý tài liệu luật, checklist cho hệ thống AI
              </p>
            </div>
          <div className="flex gap-2">
            <Link href="/admin/knowledge/fda-pipeline">
              <Button variant="outline">
                <AlertTriangle className="h-4 w-4 mr-2" />
                FDA Warning Letters Pipeline
              </Button>
            </Link>
            <Button 
              variant="destructive" 
              onClick={async () => {
                if (!confirm(`Bạn có chắc muốn XÓA TẤT CẢ ${entries.length} records?\n\nHành động này KHÔNG THỂ hoàn tác!`)) {
                  return
                }
                try {
                  const response = await fetch('/api/knowledge/bulk-delete', {
                    method: 'DELETE',
                  })
                  const data = await response.json()
                  if (data.success) {
                    toast({ title: 'Thanh cong', description: `Da xoa thanh cong ${data.deleted_count} records!` })
                    window.location.reload()
                  } else {
                    toast({ title: 'Loi', description: 'Loi: ' + data.error, variant: 'destructive' })
                  }
                } catch (error: any) {
                  toast({ title: 'Loi', description: 'Loi: ' + error.message, variant: 'destructive' })
                }
              }}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Xóa tất cả
            </Button>
            <Button variant="outline" asChild>
              <a href="/admin/knowledge/re-import">
                <Upload className="mr-2 h-4 w-4" />
                Re-Import (Tối ưu)
              </a>
            </Button>
            <Button onClick={() => setShowUploadForm(!showUploadForm)}>
              {showUploadForm ? (
                <>
                  <X className="mr-2 h-4 w-4" />
                  Hủy
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Nạp tài liệu mới
                </>
              )}
            </Button>
          </div>
        </div>

        {showUploadForm && (
          <Card className="p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">Tải lên tài liệu mới</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Tiêu đề tài liệu *</Label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="VD: FDA Guidance on Nutrition Labeling"
                />
              </div>

              <div>
                <Label>Nhóm ngành</Label>
                <Select
                  value={formData.industry}
                  onValueChange={(value) => setFormData({ ...formData, industry: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Chọn ngành" />
                  </SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map((ind) => (
                      <SelectItem key={ind} value={ind}>
                        {ind}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Loại tài liệu</Label>
                <Select
                  value={formData.docType}
                  onValueChange={(value) => setFormData({ ...formData, docType: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Chọn loại" />
                  </SelectTrigger>
                  <SelectContent>
                    {DOC_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Mức độ nghiêm trọng</Label>
                <Select
                  value={formData.severity}
                  onValueChange={(value) => setFormData({ ...formData, severity: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Chọn mức độ" />
                  </SelectTrigger>
                  <SelectContent>
                    {SEVERITIES.map((sev) => (
                      <SelectItem key={sev} value={sev}>
                        {sev}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Số hiệu điều khoản (Section)</Label>
                <Input
                  value={formData.section}
                  onChange={(e) => setFormData({ ...formData, section: e.target.value })}
                  placeholder="VD: 21 CFR 101.9"
                />
              </div>

              <div>
                <Label>Nguồn</Label>
                <Input
                  value={formData.source}
                  onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                  placeholder="VD: FDA.gov"
                />
              </div>

              <div className="md:col-span-2">
                <Label>Nội dung *</Label>
                <Textarea
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="Nhập nội dung tài liệu luật hoặc checklist..."
                  rows={8}
                />
              </div>
            </div>

            <div className="mt-4 flex justify-end">
              <Button onClick={handleUpload} disabled={uploading}>
                {uploading ? 'Đang tải lên...' : 'Tải lên và Embedding'}
              </Button>
            </div>
          </Card>
        )}

        {/* Filters and Grouping */}
        <div className="space-y-4 mb-6">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Tìm kiếm trong nội dung..."
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterIndustry} onValueChange={setFilterIndustry}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Lọc theo ngành" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả ngành</SelectItem>
                {INDUSTRIES.map((ind) => (
                  <SelectItem key={ind} value={ind}>
                    {ind}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterDocType} onValueChange={setFilterDocType}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Loại tài liệu" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả loại</SelectItem>
                {DOC_TYPES.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center gap-4">
            <Label className="text-sm font-medium">Gom theo:</Label>
            <Select value={groupBy} onValueChange={(val) => { 
              setGroupBy(val as 'none' | 'section' | 'source')
              setCurrentPage(1)
              setExpandedGroups(new Set())
            }}>
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="section">Section/Chapter</SelectItem>
                <SelectItem value="source">Nguồn</SelectItem>
                <SelectItem value="none">Không gom nhóm</SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="outline" className="ml-auto">
              Tổng: {filteredEntries.length} records | {groupKeys.length} nhóm
            </Badge>
          </div>
        </div>
      </div>

      {/* Knowledge Entries List with Grouping */}
      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-8 text-muted-foreground">Đang tải...</div>
        ) : filteredEntries.length === 0 ? (
          <Card className="p-8 text-center">
            <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              {searchQuery || filterIndustry !== 'all' || filterDocType !== 'all'
                ? 'Không tìm thấy kết quả phù hợp'
                : 'Chưa có tài liệu nào. Hãy tải lên tài liệu đầu tiên!'}
            </p>
          </Card>
        ) : groupBy === 'none' ? (
          // No grouping - show flat list with pagination
          <>
            {filteredEntries.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE).map((entry) => (
              <Card key={entry.id} className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="h-5 w-5 text-primary" />
                      <h3 className="font-semibold text-lg">
                        {entry.metadata.title || 'Không có tiêu đề'}
                      </h3>
                    </div>
                    <div className="flex gap-2 mb-3">
                      {entry.metadata.industry && (
                        <Badge variant="outline">{entry.metadata.industry}</Badge>
                      )}
                      {entry.metadata.doc_type && (
                        <Badge variant="secondary">{entry.metadata.doc_type}</Badge>
                      )}
                      {entry.metadata.section && (
                        <Badge variant="outline">
                          <Tag className="h-3 w-3 mr-1" />
                          {entry.metadata.section}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(entry.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>

                <div className="text-sm text-muted-foreground bg-muted p-4 rounded-md">
                  {entry.content.slice(0, 300)}
                  {entry.content.length > 300 && '...'}
                </div>

                <div className="mt-3 text-xs text-muted-foreground">
                  Nguồn: {entry.metadata.source || 'N/A'} | Tạo lúc:{' '}
                  {new Date(entry.created_at).toLocaleString('vi-VN')}
                </div>
              </Card>
            ))}
          </>
        ) : (
          // Grouped display
          paginatedGroupKeys.map((groupKey) => {
            const groupEntries = groups[groupKey]
            const isExpanded = expandedGroups.has(groupKey)
            
            return (
              <Card key={groupKey} className="overflow-hidden">
                <div 
                  className="p-4 bg-muted/50 cursor-pointer hover:bg-muted flex items-center justify-between"
                  onClick={() => toggleGroup(groupKey)}
                >
                  <div className="flex items-center gap-3">
                    <BookOpen className="h-5 w-5 text-primary" />
                    <div>
                      <h3 className="font-semibold">{groupKey}</h3>
                      <p className="text-sm text-muted-foreground">
                        {groupEntries.length} records
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    {isExpanded ? 'Thu gọn' : 'Mở rộng'}
                  </Button>
                </div>
                
                {isExpanded && (
                  <div className="p-4 space-y-3">
                    {groupEntries.map((entry) => (
                      <div key={entry.id} className="border-l-2 border-primary/20 pl-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <FileText className="h-4 w-4 text-primary" />
                              <h4 className="font-medium text-sm">
                                {entry.metadata.title || 'Không có tiêu đề'}
                              </h4>
                            </div>
                            <div className="flex gap-2 mb-2">
                              {entry.metadata.industry && (
                                <Badge variant="outline" className="text-xs">{entry.metadata.industry}</Badge>
                              )}
                              {entry.metadata.doc_type && (
                                <Badge variant="secondary" className="text-xs">{entry.metadata.doc_type}</Badge>
                              )}
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(entry.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                        
                        <div className="text-xs text-muted-foreground bg-muted/30 p-3 rounded">
                          {entry.content.slice(0, 200)}
                          {entry.content.length > 200 && '...'}
                        </div>
                        
                        <div className="mt-2 text-xs text-muted-foreground">
                          {new Date(entry.created_at).toLocaleString('vi-VN')}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            )
          })
        )}
        
        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-6">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
            >
              Trước
            </Button>
            <div className="flex items-center gap-2">
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const page = i + 1
                return (
                  <Button
                    key={page}
                    variant={currentPage === page ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setCurrentPage(page)}
                  >
                    {page}
                  </Button>
                )
              })}
              {totalPages > 5 && <span className="text-muted-foreground">...</span>}
              {totalPages > 5 && (
                <Button
                  variant={currentPage === totalPages ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setCurrentPage(totalPages)}
                >
                  {totalPages}
                </Button>
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
            >
              Sau
            </Button>
          </div>
        )}
      </div>
    </div>
    </div>
  )
}
