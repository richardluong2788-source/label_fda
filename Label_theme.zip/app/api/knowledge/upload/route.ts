import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { generateEmbedding, chunkText } from '@/lib/embedding-utils'

export async function POST(request: Request) {
  try {
    const { content, metadata } = await request.json()

    if (!content) {
      return NextResponse.json({ error: 'Content is required' }, { status: 400 })
    }

    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if user is admin
    const { data: adminUser } = await supabase
      .from('admin_users')
      .select('role')
      .eq('user_id', user.id)
      .single()

    if (!adminUser || !['admin', 'superadmin', 'expert'].includes(adminUser.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    console.log('[v0] Chunking document...')
    // Split content into chunks for better retrieval (optimal: 600 chars for FDA regulations)
    const chunks = chunkText(content, 600, 150)
    console.log('[v0] Created', chunks.length, 'chunks')

    const insertedChunks = []

    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i]
      console.log('[v0] Processing chunk', i + 1, 'of', chunks.length)

      // Generate embedding for chunk
      const embedding = await generateEmbedding(chunk)

      // Add chunk metadata
      const chunkMetadata = {
        ...metadata,
        chunk_index: i,
        total_chunks: chunks.length,
        chunk_size: chunk.length,
      }

      // Insert into database
      const { data, error } = await supabase
        .from('compliance_knowledge')
        .insert({
          content: chunk,
          metadata: chunkMetadata,
          embedding: embedding,
        })
        .select()
        .single()

      if (error) {
        console.error('[v0] Error inserting chunk:', error)
        throw error
      }

      insertedChunks.push(data)
    }

    console.log('[v0] Successfully inserted', insertedChunks.length, 'chunks')

    return NextResponse.json({
      success: true,
      chunks_created: insertedChunks.length,
      ids: insertedChunks.map((c) => c.id),
    })
  } catch (error: any) {
    console.error('[v0] Upload error:', error)
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    )
  }
}
