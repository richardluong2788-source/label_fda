import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { generateEmbedding, generateEmbeddingsBatch } from '@/lib/embedding-utils'
import { buildCorrectMetadata, inferPartNumberFromFileName } from '@/lib/rag/cfr-metadata-mapper'

/**
 * Bulk import 21 CFR Part 101 regulations into Knowledge Base
 * Expects JSON with structure: { sections: [{ id, title, content, subsections }] }
 */
export async function POST(request: Request) {
  try {
    const requestData = await request.json()
    
    console.log('[v0] ========== BULK IMPORT STARTING ==========')
    console.log('[v0] Request data:', requestData)

    let data = requestData

    // If fileUrl is provided, fetch JSON from storage
    if (requestData.fileUrl) {
      console.log('[v0] Fetching JSON from storage URL:', requestData.fileUrl)
      console.log('[v0] WARNING: Large file detected, using streaming if needed')
      
      const fileResponse = await fetch(requestData.fileUrl)
      if (!fileResponse.ok) {
        throw new Error('Failed to fetch file from storage')
      }
      
      // Check content length
      const contentLength = fileResponse.headers.get('content-length')
      const fileSizeMB = contentLength ? parseInt(contentLength) / 1024 / 1024 : 0
      console.log('[v0] File size:', fileSizeMB.toFixed(2), 'MB')
      
      // For files > 10MB, we should process in chunks to avoid memory issues
      // But for JSON, we need the full structure, so we parse it carefully
      const fileText = await fileResponse.text()
      console.log('[v0] File downloaded, parsing JSON...')
      
      // Parse JSON with error handling
      try {
        data = JSON.parse(fileText)
        console.log('[v0] JSON parsed successfully, size in memory: ~', (fileText.length / 1024 / 1024 * 2).toFixed(2), 'MB (estimated)')
      } catch (parseError: any) {
        throw new Error(`JSON parsing failed: ${parseError.message}. File may be corrupted or not valid JSON.`)
      }
    }
    
    console.log('[v0] Received data keys:', Object.keys(data))

    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: 'Unauthorized - Please login first' }, { status: 401 })
    }

    // Check if user is admin
    const { data: adminUser } = await supabase
      .from('admin_users')
      .select('role')
      .eq('user_id', user.id)
      .single()

    if (!adminUser || !['admin', 'superadmin'].includes(adminUser.role)) {
      return NextResponse.json({ 
        error: 'Forbidden - Only admins can bulk import regulations' 
      }, { status: 403 })
    }

    console.log('[v0] User authorized:', user.email, '- Role:', adminUser.role)

    // Parse 21 CFR Part 101 JSON structure
    let sections = []
    
    // Try different JSON structures
    if (data.sections) {
      sections = data.sections
    } else if (Array.isArray(data)) {
      sections = data
    } else if (data.regulations) {
      sections = data.regulations
    } else if (data.cfr) {
      sections = data.cfr
    } else {
      // If single object, wrap in array
      sections = [data]
    }

    // Infer CFR part number hint from the file name if provided
    // e.g. "21cfr701.json" → "701", helps buildCorrectMetadata pick the right mapping
    const fileNameHint = requestData.fileName || requestData.fileUrl || ''
    const partNumberHint = inferPartNumberFromFileName(fileNameHint)
    console.log('[v0] Part number hint from file name:', partNumberHint ?? '(none — will auto-detect per chunk)')

    console.log('[v0] Found', sections.length, 'sections to import')

    if (sections.length === 0) {
      return NextResponse.json({ 
        error: 'No sections found in JSON. Expected structure: { sections: [...] }' 
      }, { status: 400 })
    }

    const insertedRecords = []
    let totalChunks = 0
    let skippedSections = 0

    console.log('[v0] OPTIMIZED BATCH PROCESSING - Processing sections in batches...')
    const BATCH_SIZE = 20 // Process 20 sections at a time (optimized for speed)

    for (let batchStart = 0; batchStart < sections.length; batchStart += BATCH_SIZE) {
      const batchEnd = Math.min(batchStart + BATCH_SIZE, sections.length)
      const batchSections = sections.slice(batchStart, batchEnd)
      
      console.log(`[v0] ========== BATCH ${Math.floor(batchStart / BATCH_SIZE) + 1}/${Math.ceil(sections.length / BATCH_SIZE)} ==========`)
      console.log(`[v0] Processing sections ${batchStart + 1}-${batchEnd} of ${sections.length}`)

      // Prepare all chunks for this batch
      const batchChunks: Array<{
        content: string
        metadata: any
        sectionId: string
      }> = []

      for (let i = 0; i < batchSections.length; i++) {
        const section = batchSections[i]
        const sectionId = section.id || section.section || section.regulation_id || `section_${batchStart + i}`
        const title = section.title || section.name || section.heading || 'Untitled'
        let content = section.content || section.text || section.body || ''
        
        // Handle subsections
        if (section.subsections && Array.isArray(section.subsections)) {
          for (const sub of section.subsections) {
            const subContent = sub.content || sub.text || sub.body || ''
            content += `\n\n${sub.id || sub.section || 'Subsection'}: ${sub.title || ''}\n${subContent}`
          }
        }

        // Skip if no content (early exit)
        if (!content || content.trim().length < 50) {
          skippedSections++
          continue
        }

        // Chunk content
        const chunks = chunkTextForCFR(content, 600, 150)
        
        for (let chunkIndex = 0; chunkIndex < chunks.length; chunkIndex++) {
          const chunkContent = chunks[chunkIndex]

          // Build base metadata, then let buildCorrectMetadata auto-detect
          // CFR part from the chunk content and override source/industry/category.
          // This prevents the "Part 701 stored as Food & Beverages" class of bugs.
          const baseMetadata = {
            regulation_id: sectionId,
            title: title,
            section: sectionId,
            // Defaults — will be overridden by buildCorrectMetadata if part is detected
            source: '21 CFR Part 101',
            document_type: 'FDA Regulation',
            industry: 'Food & Beverages',
            chunk_index: chunkIndex,
            total_chunks: chunks.length,
            imported_at: new Date().toISOString(),
            imported_by: user.email,
          }

          const correctedMetadata = buildCorrectMetadata(chunkContent, partNumberHint, baseMetadata)

          batchChunks.push({
            content: chunkContent,
            metadata: correctedMetadata,
            sectionId: sectionId,
          })
        }
      }

      if (batchChunks.length === 0) {
        console.log('[v0] No valid chunks in this batch, skipping...')
        continue
      }

      console.log(`[v0] Batch prepared: ${batchChunks.length} chunks from ${batchSections.length} sections`)
      
      // BATCH GENERATE EMBEDDINGS (all at once)
      console.log('[v0] Generating embeddings in batch...')
      const embeddings = await generateEmbeddingsBatch(batchChunks.map(c => c.content))
      console.log('[v0] Generated', embeddings.length, 'embeddings')

      // BATCH INSERT INTO DATABASE
      console.log('[v0] Inserting batch into database...')
      const recordsToInsert = batchChunks.map((chunk, idx) => ({
        content: chunk.content,
        metadata: chunk.metadata,
        embedding: embeddings[idx],
      }))

      const { data: inserted, error: batchError } = await supabase
        .from('compliance_knowledge')
        .insert(recordsToInsert)
        .select()

      if (batchError) {
        console.error('[v0] Batch insert error:', batchError)
        // Continue with next batch
        continue
      }

      insertedRecords.push(...(inserted || []))
      totalChunks += batchChunks.length

      console.log(`[v0] Batch complete: ${inserted?.length || 0} records inserted`)
      console.log(`[v0] Progress: ${totalChunks} total chunks, ${skippedSections} sections skipped`)

      // Shorter pause between batches (1 second instead of 3)
      if (batchEnd < sections.length) {
        await new Promise(resolve => setTimeout(resolve, 1000))
      }
    }

    console.log('[v0] ========== BULK IMPORT COMPLETE ==========')
    console.log('[v0] Total sections processed:', sections.length)
    console.log('[v0] Total chunks inserted:', totalChunks)
    console.log('[v0] Skipped sections:', skippedSections)

    return NextResponse.json({
      success: true,
      message: '21 CFR Part 101 imported successfully',
      stats: {
        sections_processed: sections.length,
        sections_skipped: skippedSections,
        chunks_created: totalChunks,
        records_inserted: insertedRecords.length,
      },
      sample_ids: insertedRecords.slice(0, 5).map(r => r.id),
    })

  } catch (error: any) {
    console.error('[v0] Bulk import error:', error)
    return NextResponse.json(
      { 
        error: error.message || 'Internal server error',
        details: error.toString(),
      },
      { status: 500 }
    )
  }
}

/**
 * Chunk text specifically for CFR regulations
 * Optimal chunk size: 500-800 chars for legal/regulatory text to improve semantic similarity
 * Tries to break at section boundaries when possible
 */
function chunkTextForCFR(
  text: string,
  maxChunkSize: number = 600,
  overlap: number = 150
): string[] {
  const chunks: string[] = []
  
  // Try to split by paragraphs first
  const paragraphs = text.split(/\n\n+/)
  let currentChunk = ''
  
  for (const para of paragraphs) {
    if ((currentChunk + para).length > maxChunkSize && currentChunk.length > 0) {
      // Current chunk is full, save it
      chunks.push(currentChunk.trim())
      
      // Start new chunk with overlap
      const overlapText = currentChunk.slice(-overlap)
      currentChunk = overlapText + '\n\n' + para
    } else {
      currentChunk += (currentChunk ? '\n\n' : '') + para
    }
  }
  
  // Add last chunk
  if (currentChunk.trim()) {
    chunks.push(currentChunk.trim())
  }
  
  return chunks.filter(c => c.length > 50) // Filter out tiny chunks
}
